// ============================================================
//  ATDC — TX (ESP32) | 3 Tanks
//  Working code — Ravindra Prasad M S | 1SI22ET044
//  SIT Tumakuru | 8th Semester | 2025-26
//
//  Sensor Pins:
//    Tank 1: TRIG=5,  ECHO=18
//    Tank 2: TRIG=19, ECHO=21
//    Tank 3: TRIG=22, ECHO=23
//  LoRa: UART2 GPIO16(RX) GPIO17(TX) @ 38400 baud
//  Address: 1  →  Sends to Address: 2
// ============================================================

#include <HardwareSerial.h>

HardwareSerial lora(2);

// -------- Sensor Pins --------
#define TRIG1 5
#define ECHO1 18

#define TRIG2 19
#define ECHO2 21

#define TRIG3 22
#define ECHO3 23

long duration;
String payload = "";
String lastPayload = "";

// ---------- Read Distance ----------
float readDistance(int trigPin, int echoPin)
{
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration = pulseIn(echoPin, HIGH, 30000);

  if (duration == 0) return -1;

  return duration * 0.034 / 2.0;
}

// ---------- Tank State ----------
char getState(float d)
{
  if (d < 0) return 'X';

  if (d < 20) return 'O';      // Overflow
  else if (d < 40) return 'F'; // Full
  else if (d < 80) return 'M'; // Medium
  else return 'E';             // Empty
}

void setup()
{
  Serial.begin(115200);

  lora.begin(38400, SERIAL_8N1, 16, 17);

  pinMode(TRIG1, OUTPUT);
  pinMode(ECHO1, INPUT);

  pinMode(TRIG2, OUTPUT);
  pinMode(ECHO2, INPUT);

  pinMode(TRIG3, OUTPUT);
  pinMode(ECHO3, INPUT);

  delay(1000);

  Serial.println("=== TX READY ===");

  lora.println("AT"); delay(500);
  lora.println("AT+ADDRESS=1"); delay(500);
  lora.println("AT+NETWORKID=5"); delay(500);
  lora.println("AT+BAND=865000000"); delay(500);
}

void loop()
{
  float d1 = readDistance(TRIG1, ECHO1);
  delay(250);

  float d2 = readDistance(TRIG2, ECHO2);
  delay(250);

  float d3 = readDistance(TRIG3, ECHO3);
  delay(250);

  char s1 = getState(d1);
  char s2 = getState(d2);
  char s3 = getState(d3);

  payload =
    String(d1,1) + "," + s1 + "," +
    String(d2,1) + "," + s2 + "," +
    String(d3,1) + "," + s3;

  if (payload != lastPayload)
  {
    lora.print("AT+SEND=2,");
    lora.print(payload.length());
    lora.print(",");
    lora.println(payload);

    Serial.println("Sent:");
    Serial.println(payload);

    lastPayload = payload;
  }
  else
  {
    Serial.println("No change: " + payload);
  }

  delay(3000);
}
