// ============================================================
//  ATDC — RX (ESP32) | Sump + Motor + Flask
//  Working code — Ravindra Prasad M S | 1SI22ET044
//  SIT Tumakuru | 8th Semester | 2025-26
//
//  Sump Sensor: TRIG=5, ECHO=18
//  Motor Relay: GPIO 4
//  LoRa: UART2 GPIO16(RX) GPIO17(TX) @ 38400 baud
//  Address: 2  ←  Receives from Address: 1
// ============================================================

#include <WiFi.h>
#include <HTTPClient.h>
#include <HardwareSerial.h>

HardwareSerial lora(2);

// ---------- Pins ----------
#define TRIG   5
#define ECHO   18
#define MOTOR  4

// ---------- WiFi ----------
const char* ssid     = "RavindraGalaxys24";
const char* password = "12345678";

// !! CHANGE THIS TO YOUR PC IP SHOWN BY python app.py !!
const char* FLASK_URL = "http://10.251.132.28:5000/api/update";

// ---------- Variables ----------
String incoming = "";

float t1 = 0, t2 = 0, t3 = 0;
char  s1 = 'X', s2 = 'X', s3 = 'X';

float sumpDistance = 0;
float lastSump     = 0;

bool motorOn   = false;
bool lastMotor = false;

long duration;

// ---------- Read Sump Sensor ----------
float readDistance()
{
  digitalWrite(TRIG, LOW);
  delayMicroseconds(5);

  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  duration = pulseIn(ECHO, HIGH, 30000);

  if (duration == 0) return -1;

  return duration * 0.034 / 2.0;
}

// ---------- Send Data to Flask ----------
void sendToFlask()
{
  if (WiFi.status() != WL_CONNECTED) return;

  String body = "{";

  // Tank data from TX (via LoRa)
  body += "\"tank1_distance\":" + String(t1, 1) + ",";
  body += "\"tank1_state\":\""  + String(s1)    + "\",";

  body += "\"tank2_distance\":" + String(t2, 1) + ",";
  body += "\"tank2_state\":\""  + String(s2)    + "\",";

  body += "\"tank3_distance\":" + String(t3, 1) + ",";
  body += "\"tank3_state\":\""  + String(s3)    + "\",";

  // Sump data from local sensor
  body += "\"sump_distance\":"  + String(sumpDistance, 1) + ",";

  // Motor state
  body += "\"motor_on\":"       + String(motorOn ? "true" : "false");

  body += "}";

  HTTPClient http;
  http.begin(FLASK_URL);
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(5000);

  int code = http.POST(body);

  if (code == 200)
    Serial.println("Flask OK");
  else
    Serial.println("Flask Error: " + String(code));

  http.end();
}

void setup()
{
  Serial.begin(115200);

  // LoRa UART
  lora.begin(38400, SERIAL_8N1, 16, 17);

  // Sump Sensor
  pinMode(TRIG,  OUTPUT);
  pinMode(ECHO,  INPUT);

  // Relay
  pinMode(MOTOR, OUTPUT);
  digitalWrite(MOTOR, LOW);

  delay(1000);

  // LoRa Setup
  lora.println("AT");              delay(500);
  lora.println("AT+ADDRESS=2");    delay(500);
  lora.println("AT+NETWORKID=5");  delay(500);
  lora.println("AT+BAND=865000000"); delay(500);

  // WiFi
  WiFi.begin(ssid, password);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.println("RX READY — IP: " + WiFi.localIP().toString());
  Serial.println("Flask URL: " + String(FLASK_URL));
}

void loop()
{
  // ---------- Receive LoRa ----------
  while (lora.available())
  {
    char c = lora.read();

    if (c == '\n')
    {
      incoming.trim();

      if (incoming.startsWith("+RCV"))
      {
        // Format: +RCV=1,<len>,<d1,s1,d2,s2,d3,s3>,<rssi>,<snr>
        // Example: +RCV=1,17,45.9,M,42.7,M,35.6,F,-90,45

        int p1 = incoming.indexOf(',');
        int p2 = incoming.indexOf(',', p1 + 1);

        String remain = incoming.substring(p2 + 1);

        // Remove RSSI (last field)
        int last1 = remain.lastIndexOf(',');
        remain = remain.substring(0, last1);

        // Remove SNR (now last field)
        int last2 = remain.lastIndexOf(',');
        remain = remain.substring(0, last2);

        // remain is now: "d1,s1,d2,s2,d3,s3"
        sscanf(remain.c_str(),
               "%f,%c,%f,%c,%f,%c",
               &t1, &s1,
               &t2, &s2,
               &t3, &s3);

        Serial.println("------ TANK DATA (from TX) ------");
        Serial.println("Tank1: " + String(t1, 1) + " cm  State: " + String(s1));
        Serial.println("Tank2: " + String(t2, 1) + " cm  State: " + String(s2));
        Serial.println("Tank3: " + String(t3, 1) + " cm  State: " + String(s3));
      }

      incoming = "";
    }
    else
    {
      incoming += c;
    }
  }

  // ---------- Read Sump ----------
  sumpDistance = readDistance();

  if (sumpDistance < 0) {
    Serial.println("Sump sensor error");
    delay(1000);
    return;
  }

  bool sumpReady = (sumpDistance < 40);

  // ---------- Motor Logic ----------
  // Motor ON when: any tank needs water (E or M) AND sump has water
  motorOn =
    ((s1 == 'E' || s1 == 'M') ||
     (s2 == 'E' || s2 == 'M') ||
     (s3 == 'E' || s3 == 'M')) && sumpReady;

  digitalWrite(MOTOR, motorOn ? HIGH : LOW);

  // ---------- Serial Output ----------
  Serial.println("-------------------------------");
  Serial.println("Sump  : " + String(sumpDistance, 1) + " cm");
  Serial.println("Motor : " + String(motorOn ? "ON" : "OFF"));
  Serial.println("-------------------------------");

  // ---------- Send to Flask ----------
  // Send when sump changes by >2cm OR motor state changes
  if (abs(sumpDistance - lastSump) > 2.0 || motorOn != lastMotor)
  {
    sendToFlask();
    lastSump  = sumpDistance;
    lastMotor = motorOn;
  }

  delay(3000);
}
