"""
ATDC Smart Water Level Monitoring System
3 Tanks (TX ESP32) + 1 Sump (RX ESP32) + Auto/Manual Motor
Ravindra Prasad M S | 1SI22ET044 | SIT Tumakuru | 2025-26
Run: python app.py
"""

from flask import Flask, jsonify, render_template, request, send_from_directory
from datetime import datetime
import socket

app = Flask(__name__)

# ── MOTOR CONTROL MODE ──────────────────────────────────────
# "auto"   → motor decided by tank/sump logic
# "manual" → motor controlled by dashboard button
motor_mode   = "auto"
manual_motor = False   # only used when mode = "manual"

# ── LATEST DATA ─────────────────────────────────────────────
latest = {
    # Tank 1
    "tank1_distance": 0.0,
    "tank1_state":    "X",
    "tank1_label":    "Waiting...",
    "tank1_class":    "warning",
    "tank1_pct":      0,
    # Tank 2
    "tank2_distance": 0.0,
    "tank2_state":    "X",
    "tank2_label":    "Waiting...",
    "tank2_class":    "warning",
    "tank2_pct":      0,
    # Tank 3
    "tank3_distance": 0.0,
    "tank3_state":    "X",
    "tank3_label":    "Waiting...",
    "tank3_class":    "warning",
    "tank3_pct":      0,
    # Sump
    "sump_distance":  0.0,
    "sump_status":    "SE",
    "sump_label":     "Waiting...",
    "sump_class":     "warning",
    "sump_pct":       0,
    # Motor
    "motor_on":       False,
    "motor_label":    "STOPPED",
    "motor_mode":     "auto",
    # Meta
    "connected":      False,
    "esp_ip":         "—",
    "last_updated":   "Waiting for ESP32...",
}

# ── LABEL MAPS ──────────────────────────────────────────────
STATE_MAP = {
    "O": ("OVERFLOW", "info",    100),
    "F": ("FULL",     "success",  80),
    "M": ("MEDIUM",   "warning",  45),
    "E": ("EMPTY",    "danger",   10),
    "X": ("ERROR",    "danger",    0),
}

MAX_SUMP = 60  # cm — your sump depth

def parse_sump(dist):
    if dist < 0:   return "SE","ERROR",   "danger",  0
    if dist < 20:  return "SO","OVERFLOW","info",    100
    if dist < 40:  return "SF","FULL",    "success", max(0, min(100, int((1-dist/MAX_SUMP)*100)))
    return             "SE","EMPTY",  "danger",  max(0, min(100, int((1-dist/MAX_SUMP)*100)))

def auto_motor(s1, s2, s3, sump_code):
    """Auto motor logic — same as your RX Arduino code."""
    sump_ready   = sump_code in ("SF", "SO")
    any_needs    = any(s in ("E","M") for s in [s1, s2, s3])
    return sump_ready and any_needs


# ── ROUTES ──────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/app")
def mobile():
    return render_template("app.html")

@app.route("/static/sw.js")
def sw():
    return send_from_directory("static", "sw.js", mimetype="application/javascript")

@app.route("/static/manifest.json")
def manifest():
    return send_from_directory("static", "manifest.json", mimetype="application/json")

@app.route("/api/status")
def api_status():
    data = latest.copy()
    data["motor_mode"] = motor_mode
    return jsonify(data)


@app.route("/api/update", methods=["POST", "GET"])
def api_update():
    """ESP32 RX posts data here."""
    global latest, motor_mode, manual_motor
    try:
        d = request.get_json(force=True, silent=True) or request.args.to_dict()
        if not d:
            return jsonify({"error": "No data"}), 400

        # ── Parse tank states ──
        def parse_tank(key_dist, key_state):
            dist  = float(d.get(key_dist,  50))
            state = str(d.get(key_state,   "X")).strip().upper()
            label, cls, pct = STATE_MAP.get(state, ("UNKNOWN","warning",0))
            return dist, state, label, cls, pct

        t1d,t1s,t1l,t1c,t1p = parse_tank("tank1_distance","tank1_state")
        t2d,t2s,t2l,t2c,t2p = parse_tank("tank2_distance","tank2_state")
        t3d,t3s,t3l,t3c,t3p = parse_tank("tank3_distance","tank3_state")

        # ── Parse sump ──
        sd = float(d.get("sump_distance", 50))
        sc, sl, scls, sp = parse_sump(sd)

        # ── Motor decision ──
        esp_motor = bool(d.get("motor_on", False))
        if motor_mode == "auto":
            # Use dashboard auto logic (same as ESP32)
            final_motor = auto_motor(t1s, t2s, t3s, sc)
        else:
            # Manual — dashboard controls relay via /api/motor
            final_motor = manual_motor

        now = datetime.now().strftime("%d %b %Y  %H:%M:%S")

        latest = {
            "tank1_distance": round(t1d,1), "tank1_state": t1s,
            "tank1_label":    t1l,          "tank1_class": t1c, "tank1_pct": t1p,
            "tank2_distance": round(t2d,1), "tank2_state": t2s,
            "tank2_label":    t2l,          "tank2_class": t2c, "tank2_pct": t2p,
            "tank3_distance": round(t3d,1), "tank3_state": t3s,
            "tank3_label":    t3l,          "tank3_class": t3c, "tank3_pct": t3p,
            "sump_distance":  round(sd,1),  "sump_status": sc,
            "sump_label":     sl,           "sump_class":  scls, "sump_pct": sp,
            "motor_on":       final_motor,
            "motor_label":    "RUNNING" if final_motor else "STOPPED",
            "motor_mode":     motor_mode,
            "connected":      True,
            "esp_ip":         request.remote_addr,
            "last_updated":   now,
        }

        print(f"[ESP32] T1:{t1s}({t1d}cm) T2:{t2s}({t2d}cm) T3:{t3s}({t3d}cm) "
              f"Sump:{sc}({sd}cm) Motor:{'ON' if final_motor else 'OFF'} Mode:{motor_mode}")

        return jsonify({"status":"ok","motor_on":final_motor}), 200

    except Exception as e:
        print(f"[Error] {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/motor", methods=["POST"])
def api_motor():
    """
    Dashboard sends motor control commands here.
    Body: {"mode":"auto"} or {"mode":"manual","state":true/false}
    """
    global motor_mode, manual_motor
    try:
        d = request.get_json(force=True, silent=True) or {}
        mode = d.get("mode", motor_mode)

        if mode == "auto":
            motor_mode = "auto"
            print("[Motor] Switched to AUTO mode")
        elif mode == "manual":
            motor_mode   = "manual"
            manual_motor = bool(d.get("state", False))
            latest["motor_on"]    = manual_motor
            latest["motor_label"] = "RUNNING" if manual_motor else "STOPPED"
            print(f"[Motor] MANUAL → {'ON' if manual_motor else 'OFF'}")

        latest["motor_mode"] = motor_mode
        return jsonify({"status":"ok","mode":motor_mode,"motor_on":latest["motor_on"]}), 200

    except Exception as e:
        return jsonify({"error":str(e)}), 500


@app.route("/test")
def test():
    """Simulate ESP32 data without hardware."""
    import requests as req
    tank  = request.args.get("tank","M")
    dist  = float(request.args.get("dist","35"))
    motor = request.args.get("motor","false") == "true"
    payload = {
        "tank1_distance": dist,      "tank1_state": tank,
        "tank2_distance": dist+5,    "tank2_state": "F",
        "tank3_distance": dist+10,   "tank3_state": "E",
        "sump_distance":  20.0,      "motor_on":    motor,
    }
    req.post("http://127.0.0.1:5000/api/update", json=payload)
    return f"""<html><body style="font-family:monospace;background:#010a18;color:#00b4ff;padding:24px">
    <h3>Test sent!</h3>
    <p>Tank1:{tank}({dist}cm) Tank2:F Tank3:E Sump:SF Motor:{motor}</p>
    <a href="/" style="color:#00f5d4">Dashboard</a>
    </body></html>"""


# ── START ────────────────────────────────────────────────────
if __name__ == "__main__":
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except:
        local_ip = "127.0.0.1"

    print("\n" + "="*58)
    print("  ATDC — 3-Tank Water Level Monitor")
    print("="*58)
    print(f"  Dashboard  → http://127.0.0.1:5000")
    print(f"  Mobile App → http://{local_ip}:5000/app")
    print(f"  ESP32 URL  → http://{local_ip}:5000/api/update")
    print(f"  Test URL   → http://127.0.0.1:5000/test?tank=E&dist=55")
    print(f"\n  Put this in Arduino RX FLASK_URL:")
    print(f'  const char* FLASK_URL = "http://{local_ip}:5000/api/update";')
    print("="*58 + "\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
