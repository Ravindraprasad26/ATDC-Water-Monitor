╔══════════════════════════════════════════════════════════╗
║   ATDC SMART WATER LEVEL MONITORING SYSTEM — v4         ║
║   3 Tanks (TX ESP32) + 1 Sump (RX ESP32) + Dashboard   ║
║   Ravindra Prasad M S | 1SI22ET044 | 8th Sem           ║
║   SIT Tumakuru | E&TE Department | 2025-26              ║
╚══════════════════════════════════════════════════════════╝

PROJECT STRUCTURE
─────────────────
ATDC-Water-Monitor-v4/
├── app.py                     ← Flask server (run this)
├── requirements.txt
├── Procfile                   ← For Render.com deployment
├── TX_3Tank_ESP32.ino         ← Upload to TX ESP32
├── RX_Sump_Motor_ESP32.ino    ← Upload to RX ESP32
├── static/
│   ├── atdc_logo.jpeg
│   ├── manifest.json          ← PWA install
│   └── sw.js                  ← Offline support
└── templates/
    ├── index.html             ← Web dashboard (3 tanks)
    └── app.html               ← Mobile PWA app

HARDWARE SETUP
──────────────
TX ESP32 (3 Tank Sensors):
  Tank 1: TRIG=5,  ECHO=18
  Tank 2: TRIG=19, ECHO=21
  Tank 3: TRIG=22, ECHO=23
  LoRa:   RX=16, TX=17  @ 38400 baud  Address=1

RX ESP32 (Sump + Motor):
  Sump:   TRIG=5, ECHO=18
  Motor:  GPIO=4 (relay)
  LoRa:   RX=16, TX=17  @ 38400 baud  Address=2
  WiFi:   Connected to hotspot

STEPS TO RUN
────────────
1. Run Flask:
   pip install -r requirements.txt
   python app.py

2. Copy the IP shown:
   ESP32 URL → http://10.x.x.x:5000/api/update

3. Open RX_Sump_Motor_ESP32.ino in Arduino IDE
   Change: const char* FLASK_URL = "http://YOUR_IP:5000/api/update";
   Upload to RX ESP32

4. Upload TX_3Tank_ESP32.ino to TX ESP32

5. Open browser → http://127.0.0.1:5000

MOTOR LOGIC
───────────
Motor ON when:
  ANY tank is EMPTY (E) or MEDIUM (M)
  AND Sump has water (distance < 40cm)

Motor OFF when:
  ALL tanks are FULL or OVERFLOW
  OR Sump is EMPTY (distance >= 40cm)

DISTANCE ZONES (same for all tanks and sump)
─────────────────────────────────────────────
  < 20 cm  → OVERFLOW (O)
  20-40 cm → FULL (F)
  40-80 cm → MEDIUM (M)   [tanks only]
  > 40 cm  → EMPTY (E)   [sump: > 40 = empty]

AUTO/MANUAL MOTOR CONTROL
──────────────────────────
Dashboard has AUTO/MANUAL toggle button:
  AUTO   → motor controlled automatically by logic
  MANUAL → you press ON/OFF buttons to control motor

TEST WITHOUT HARDWARE
──────────────────────
http://127.0.0.1:5000/test?tank=E&dist=55
http://127.0.0.1:5000/test?tank=F&dist=15
